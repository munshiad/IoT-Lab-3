# import machine, I2C
from machine import Pin, I2C, RTC, ADC
# import ssd1306_old as ssd1306
import ssd1306
from time import sleep

# globals that are modified by interrupts


# light sensor
lightSensor = ADC(0)

def main():
    # ESP8266 Pin assignment
    i2c = I2C(-1, scl=Pin(5), sda=Pin(4))

    # setup oled
    oled_width = 128
    oled_height = 32
    oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)
    while True:
        oled.contrast(lightSensor.read())

        oled.fill(0)

        oled.text('Bananas', 0, 0)
        oled.text('Apples', 0, 10)
        oled.text('Oranges', 0, 20)

        oled.show()

if __name__ == "__main__":
    main()