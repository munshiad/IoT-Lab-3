# import machine, I2C
from machine import Pin, I2C, RTC, ADC
# import ssd1306_old as ssd1306
import ssd1306
from time import sleep

# globals that are modified by interrupts
mode = 0  # 0 == "regular mode", 1 = "set year", 2 = "set month", etc.
alarm_mode = 0  # 0 == "not in alarm mode", 1 = "in alarm mode, hour", 2 = "in alarm mode, minute"
incPressed = False

# buttons
button_A = Pin(2, Pin.IN)
button_B = Pin(13, Pin.IN)
button_C = Pin(15, Pin.IN) #manual button because button C broken

last_mode = 8

def mode_pressed_callback(pin):
    global mode
    global interrupt_pin
    interrupt_pin = pin

    sleep(0.05)  # DEBOUNCE

    # increment: will use mod to get the mode
    mode += 1

def inc_pressed_callback(pin):
    global interrupt_pin
    global incPressed
    interrupt_pin = pin
    sleep(0.05)
    print("pressed")
    incPressed = True

def alarm_pressed_callback(pin):
        global interrupt_pin
        global alarm_mode
        interrupt_pin = pin
        sleep(0.05)
        print("pressed button c")

# attach interrupt to button a
button_A.irq(trigger=Pin.IRQ_RISING, handler=mode_pressed_callback)  # when there is a change

# attach interrupt to button b
button_B.irq(trigger=Pin.IRQ_RISING, handler=inc_pressed_callback)

def main():
    global mode
    global last_mode
    global incPressed

    haveTime = False

    # ESP8266 Pin assignment
    i2c = I2C(-1, scl=Pin(5), sda=Pin(4))

    # setup oled
    oled_width = 128
    oled_height = 32
    oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)
    oled.fill(1)



    # main loop
    while True:
        oled.fill(1)

if __name__ == "__main__":
    main()